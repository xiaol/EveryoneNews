//
//  BigImgFrm.m
//  EveryoneNews
//
//  Created by 于咏畅 on 15/4/21.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import "BigImgFrm.h"

@implementation BigImgFrm

- (void)setBigImgDatasource:(BigImgDatasource *)bigImgDatasource
{
    _bigImgDatasource = bigImgDatasource;
    
    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    
    CGFloat backH;
    
    CGFloat maxY;
    
//    if (screenW == 320) {
    backH = 412 / 2;
    _backFrm = CGRectMake(0, 0, screenW, backH);
    _imgFrm = CGRectMake(0, 0, screenW, backH);
    _cutlineFrm = CGRectMake(0, backH, screenW, 8);
    maxY = CGRectGetMaxY(_cutlineFrm);
        
//    } else {
////        CGFloat backH = 195;
//        backH = 412 / 2 + 20;
//        _backFrm = CGRectMake(0, 0, screenW, backH);
////        CGFloat imgX = 78;
//        CGFloat imgY = 20;
////        CGFloat imgW = 800 / 3;
//        CGFloat imgW = 320;
//        CGFloat imgX = (screenW - 320) / 2;
////        CGFloat imgH = 464 / 3;
//        CGFloat imgH = 412 / 2;
//        _imgFrm = CGRectMake(imgX, imgY, imgW, imgH);
//        _cutlineFrm = CGRectMake(0, 0, 0, 0);
//        maxY = backH;
//    }
    
    CGFloat titleY = CGRectGetMaxY(_imgFrm) - 50;
    CGFloat titleX = _imgFrm.origin.x + 24;
    _titleFrm = CGRectMake(titleX, titleY + 5, screenW - 2 * titleX, 40);
    
    CGFloat toumuX = _imgFrm.origin.x;
    _toumuFrm = CGRectMake(toumuX, titleY, _imgFrm.size.width, 50);
    
    CGFloat categoryX = CGRectGetMaxX(_titleFrm);
    CGFloat categoryY = 142 / 3;
    _categoryFrm = CGRectMake(categoryX, categoryY, 18, 36);
    
//    CGFloat maxY = CGRectGetMaxY(_cutlineFrm);
//    _backFrm = CGRectMake(0, 0, screenW, maxY);
    
//    _CellH = CGRectGetMaxY(_cutlineFrm);
    _CellH = maxY;
}

@end
