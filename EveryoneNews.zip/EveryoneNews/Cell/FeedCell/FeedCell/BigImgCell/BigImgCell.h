//
//  BigImgCell.h
//  EveryoneNews
//
//  Created by 于咏畅 on 15/4/21.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseFeedCell.h"
#import "BigImgFrm.h"

@interface BigImgCell : BaseFeedCell

@property (strong, nonatomic) BigImgFrm *bigImgFrm;

@end
