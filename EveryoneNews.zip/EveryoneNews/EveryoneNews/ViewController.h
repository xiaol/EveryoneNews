//
//  ViewController.h
//  EveryoneNews
//
//  Created by 于咏畅 on 15/3/23.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BaseViewController.h"

@interface ViewController : BaseViewController 


@end

