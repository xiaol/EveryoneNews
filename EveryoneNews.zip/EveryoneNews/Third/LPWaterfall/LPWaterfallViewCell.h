//
//  LPWaterfallViewCell.h
//  WaterFlow
//
//  Created by apple on 15/4/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPWaterfallViewCell : UIView
@property (nonatomic, copy) NSString *identifier;
@end
