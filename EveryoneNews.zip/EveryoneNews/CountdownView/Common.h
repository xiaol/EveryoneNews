//
//  Common.h
//  testString
//
//  Created by apple on 15/5/10.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#ifndef testString_Common_h
#define testString_Common_h

#define threeDotFiveInch ([UIScreen mainScreen].bounds.size.height == 480)
#define fourInch ([UIScreen mainScreen].bounds.size.height == 568)
#define fourDotSevenInch ([UIScreen mainScreen].bounds.size.height == 667)
#define fiveDotFiveInch ([UIScreen mainScreen].bounds.size.height == 736)

#endif
