//
//  SineLayout.h
//  EveryoneNews
//
//  Created by apple on 15/10/11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SineLayout : UICollectionViewFlowLayout

@end
