//
//  LPFullPhotoViewController.h
//  EveryoneNews
//
//  Created by dongdan on 15/11/26.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "LPBaseViewController.h"

@interface LPFullPhotoViewController : LPBaseViewController
@property (nonatomic, strong) NSURL *imageURL;
@end
