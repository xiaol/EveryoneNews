//
//  CollectCell.h
//  EveryoneNews
//
//  Created by apple on 15/10/15.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "AlbumCell.h"

@interface CollectCell : AlbumCell
//@property (nonatomic, strong) UIView *selectedHUD;
@end
