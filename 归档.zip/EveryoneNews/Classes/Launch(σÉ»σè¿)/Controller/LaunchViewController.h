//
//  LaunchViewController.h
//  EveryoneNews
//
//  Created by apple on 15/7/20.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LaunchViewController : UIViewController

@end
