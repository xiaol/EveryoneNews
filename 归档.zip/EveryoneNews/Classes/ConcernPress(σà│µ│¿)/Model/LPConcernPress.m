//
//  LPConcernPress.m
//  EveryoneNews
//
//  Created by apple on 15/7/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "LPConcernPress.h"

@implementation LPConcernPress

@end
