//
//  ConcernViewController.h
//  EveryoneNews
//
//  Created by apple on 15/7/17.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LPConcern;

@interface ConcernViewController : LPBaseViewController
@property (nonatomic, strong) LPConcern *concern;
@end
