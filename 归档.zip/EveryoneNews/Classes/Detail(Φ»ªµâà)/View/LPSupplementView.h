//
//  LPSupplementView.h
//  EveryoneNews
//
//  Created by apple on 15/8/5.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LPContentFrame;

@interface LPSupplementView : UIView
@property (nonatomic, strong) LPContentFrame *contentFrame;
@end
