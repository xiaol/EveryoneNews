//
//  LPUpButton.h
//  EveryoneNews
//
//  Created by apple on 15/6/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPUpButton : UIButton

@end
