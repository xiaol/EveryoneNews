//
//  LPPhotoCell.h
//  EveryoneNews
//
//  Created by apple on 15/8/13.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LPPhoto;

@interface LPPhotoCell : UICollectionViewCell
@property (nonatomic, strong) LPPhoto *photo;
@end
