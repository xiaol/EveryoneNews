//
//  LPFullPhotoCell.h
//  EveryoneNews
//
//  Created by apple on 15/8/14.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LPPhoto;

@interface LPFullPhotoCell : UICollectionViewCell
@property (nonatomic, strong) LPPhoto *photo;
@end
