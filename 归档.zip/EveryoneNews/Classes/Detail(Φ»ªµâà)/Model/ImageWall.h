//
//  ImageWall.h
//  EveryoneNews
//
//  Created by Feng on 15/7/10.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageWall : NSObject
@property (nonatomic,copy) NSString *note;
@property (nonatomic,copy) NSString *img;


@end
