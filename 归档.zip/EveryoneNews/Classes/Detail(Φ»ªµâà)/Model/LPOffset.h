//
//  LPOffset.h
//  EveryoneNews
//
//  Created by apple on 15/6/14.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LPOffset : NSObject

@property (nonatomic, assign) CGFloat y;

@end
