//
//  LPPhoto.h
//  EveryoneNews
//
//  Created by apple on 15/8/13.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LPPhoto : NSObject
@property (nonatomic, copy) NSString *note;
@property (nonatomic, copy) NSString *img;
@end
