//
//  LPZhihuPoint.h
//  EveryoneNews
//
//  Created by apple on 15/6/9.
//  Copyright (c) 2015年 apple. All rights reserved.
//
//"url": "http://www.zhihu.com/question/27782102",
//"user": "飞鸟",
//"title": "华为手机消费母公司的口碑做手机会不会得不偿失？"
#import <Foundation/Foundation.h>

@interface LPZhihuPoint : NSObject
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *user;
@property (nonatomic, copy) NSString *title;
@end
