//
//  LPDetail.m
//  EveryoneNews
//
//  Created by dongdan on 15/12/31.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "LPDetail.h"

 
@implementation LPDetail



@end
