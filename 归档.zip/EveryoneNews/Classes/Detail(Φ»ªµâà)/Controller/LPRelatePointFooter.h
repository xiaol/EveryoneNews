//
//  LPRelatePointFooter.h
//  EveryoneNews
//
//  Created by dongdan on 16/4/13.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "MJRefreshAutoFooter.h"

@interface LPRelatePointFooter : MJRefreshAutoFooter

@end
