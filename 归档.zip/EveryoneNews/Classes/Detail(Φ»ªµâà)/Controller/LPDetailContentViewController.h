//
//  LPContentDetailViewController.h
//  EveryoneNews
//
//  Created by dongdan on 15/12/30.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "LPBaseViewController.h"
#import "Card.h"

@interface LPDetailContentViewController : LPBaseViewController

@property (nonatomic, strong) Card *card;

@end
