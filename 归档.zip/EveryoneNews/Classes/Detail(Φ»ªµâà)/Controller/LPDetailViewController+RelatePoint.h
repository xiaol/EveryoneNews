//
//  LPDetailViewController+RelatePoint.h
//  EveryoneNews
//
//  Created by dongdan on 16/4/9.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPDetailViewController.h"

@interface LPDetailViewController (RelatePoint)

- (void)loadMoreRelateData;

@end
