//
//  LPPhotoWallViewController.h
//  EveryoneNews
//
//  Created by apple on 15/8/14.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "LPBaseViewController.h"

@interface LPPhotoWallViewController : LPBaseViewController
@property (nonatomic, strong) NSArray *photos;
@property (nonatomic, strong) NSIndexPath *originIndexPath;
@end
