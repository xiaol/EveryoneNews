//
//  LPNewsPrivacyItemsController.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/13.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPNewsBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LPNewsPrivacyItemsController : LPNewsBaseViewController

@end

NS_ASSUME_NONNULL_END