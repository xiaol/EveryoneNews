//
//  Content.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "Content.h"
#import "ContentPhoto.h"
#import "Press.h"

@implementation Content

// Insert code here to add functionality to your managed object subclass

@end
