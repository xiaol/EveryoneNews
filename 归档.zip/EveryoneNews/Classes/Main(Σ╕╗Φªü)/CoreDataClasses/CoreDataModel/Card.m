//
//  Card.m
//  EveryoneNews
//
//  Created by dongdan on 16/3/23.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "Card.h"
#import "CardImage.h"
#import "CardRelate.h"

@implementation Card

// Insert code here to add functionality to your managed object subclass

@end
