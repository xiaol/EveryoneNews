//
//  AlbumPhoto.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "AlbumPhoto.h"
#import "Album.h"

@implementation AlbumPhoto

// Insert code here to add functionality to your managed object subclass

@end
