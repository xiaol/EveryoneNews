//
//  Press.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "Press.h"
#import "Album.h"
#import "Content.h"
#import "PressPhoto.h"
#import "Relate.h"
#import "Zhihu.h"

@implementation Press

// Insert code here to add functionality to your managed object subclass

@end
