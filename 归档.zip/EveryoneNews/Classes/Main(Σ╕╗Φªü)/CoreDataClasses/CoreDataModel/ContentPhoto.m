//
//  ContentPhoto.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "ContentPhoto.h"
#import "Content.h"

@implementation ContentPhoto

// Insert code here to add functionality to your managed object subclass

@end
