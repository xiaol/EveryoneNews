//
//  Content+CoreDataProperties.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Content+CoreDataProperties.h"

@implementation Content (CoreDataProperties)

@dynamic body;
@dynamic isPhotoType;
@dynamic paraID;
@dynamic photoURL;
@dynamic thumbnail;
@dynamic thumbnailDesc;
@dynamic photo;
@dynamic press;

@end
