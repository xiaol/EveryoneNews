//
//  CardImage.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "CardImage.h"
#import "Card.h"

@implementation CardImage

// Insert code here to add functionality to your managed object subclass

@end
