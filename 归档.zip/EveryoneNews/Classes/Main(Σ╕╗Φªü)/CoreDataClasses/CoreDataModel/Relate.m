//
//  Relate.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "Relate.h"
#import "Press.h"
#import "RelatePhoto.h"

@implementation Relate

// Insert code here to add functionality to your managed object subclass

@end
