//
//  CardRelate.m
//  EveryoneNews
//
//  Created by apple on 15/12/16.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "CardRelate.h"
#import "Card.h"

@implementation CardRelate

// Insert code here to add functionality to your managed object subclass

@end
