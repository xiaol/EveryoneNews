//
//  Press+HTTPStatus.h
//  EveryoneNews
//
//  Created by dongdan on 16/1/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "Press.h"

@interface Press (HTTPStatus)
@property (nonatomic, copy) NSString *httpStatus;
@end
