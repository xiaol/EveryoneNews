//
//  Content+PhotoDownloadCompletion.h
//  EveryoneNews
//
//  Created by dongdan on 16/2/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "Content.h"


@interface Content (PhotoDownloadCompletion)
@property (nonatomic, strong) UIImage *image;

@end
