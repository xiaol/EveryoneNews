//
//  LPNewsMyCommCell.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPNewsBaseTableViewCell.h"

@interface LPNewsMyCommCell : LPNewsBaseTableViewCell

@end
