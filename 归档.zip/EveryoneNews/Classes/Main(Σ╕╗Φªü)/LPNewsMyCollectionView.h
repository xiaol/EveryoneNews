//
//  LPNewsMyCollectionView.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/14.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPNewsBaseViewController.h"

@interface LPNewsMyCollectionView : LPNewsBaseViewController

@end
