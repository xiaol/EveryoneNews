//
//  QDNewsMineViewCell.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPNewsBaseTableViewCell.h"

static const CGFloat kMineViewCellHeight = 58.f;

@interface LPNewsMineViewCell : LPNewsBaseTableViewCell

@end
