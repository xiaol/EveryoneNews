//
//  LPSearchViewController.h
//  EveryoneNews
//
//  Created by dongdan on 16/1/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPBaseViewController.h"

@interface LPSearchViewController : LPBaseViewController

@end
