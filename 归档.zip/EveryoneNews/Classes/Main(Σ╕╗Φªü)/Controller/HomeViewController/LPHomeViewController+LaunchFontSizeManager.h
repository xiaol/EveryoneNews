//
//  LPHomeViewController+LaunchFontSizeManager.h
//  EveryoneNews
//
//  Created by dongdan on 16/4/8.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPHomeViewController.h"
#import "LPChangeFontSizeView.h"

@interface LPHomeViewController (LaunchFontSizeManager)<LPChangeFontSizeViewDelegate>

@end
