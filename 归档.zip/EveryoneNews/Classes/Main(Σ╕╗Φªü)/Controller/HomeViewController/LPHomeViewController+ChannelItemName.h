//
//  LPHomeViewController+ChannelItemName.h
//  EveryoneNews
//
//  Created by dongdan on 16/4/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPHomeViewController.h"

@interface LPHomeViewController (ChannelItemName)

- (void)initializeChannelItemName;

@end
