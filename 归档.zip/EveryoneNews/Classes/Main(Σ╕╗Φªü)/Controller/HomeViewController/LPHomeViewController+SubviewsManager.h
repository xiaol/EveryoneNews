//
//  LPHomeViewController+SubviewsManager.h
//  EveryoneNews
//
//  Created by dongdan on 16/4/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPHomeViewController.h"
#import "LPNewsMineViewController.h"
 
@interface LPHomeViewController (SubviewsManager)<LPLaunchLoginViewDelegate>


- (void)setupSubViews;

@end
