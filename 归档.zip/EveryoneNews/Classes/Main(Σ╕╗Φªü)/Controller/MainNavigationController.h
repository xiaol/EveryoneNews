//
//  HomeNavigationController.h
//  EveryoneNews
//
//  Created by Feng on 15/7/2.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface MainNavigationController : UINavigationController
@property (nonatomic, strong) UIPanGestureRecognizer *popRecognizer;
@end
