//
//  HomeViewController.h
//  EveryoneNews
//
//  Created by Feng on 15/7/2.
//  Copyright (c) 2015年 apple. All rights reserved.
//

@interface MainViewController : LPBaseViewController

@end


