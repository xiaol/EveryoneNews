//
//  LPNewsMyCommViewController.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPNewsBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LPNewsMyCommViewController : LPNewsBaseViewController

@end

NS_ASSUME_NONNULL_END