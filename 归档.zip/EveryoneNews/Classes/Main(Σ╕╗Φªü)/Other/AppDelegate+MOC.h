//
//  AppDelegate+MOC.h
//  EveryoneNews
//
//  Created by apple on 15/9/23.
//  Copyright (c) 2015年 apple. All rights reserved.
//  

#import "AppDelegate.h"

@interface AppDelegate (MOC)
//- (UIManagedDocument *)createManagedDocument;
//- (NSManagedObjectContext *)createManagedObjectContextWithDocument:(UIManagedDocument *)document;
@end
