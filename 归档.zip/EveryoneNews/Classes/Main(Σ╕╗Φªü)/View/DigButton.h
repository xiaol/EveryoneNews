//
//  DigButton.h
//  EveryoneNews
//
//  Created by apple on 15/8/31.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

extern const CGFloat DigButtonWidth;
extern const CGFloat DigButtonHeight;
extern const CGFloat DigButtonPadding;

@interface DigButton : UIButton

@end
