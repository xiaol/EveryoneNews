//
//  LPMenuView.m
//  EveryoneNews
//
//  Created by dongdan on 15/12/2.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "LPMenuView.h"
#import "LPFloodView.h"
#import "LPMenuButton.h"

@interface LPMenuView ()  

@end

@implementation LPMenuView

@end
