//
//  LPTabBarButton.h
//  EveryoneNews
//
//  Created by apple on 15/5/26.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPTabBarButton : UIButton

@property (nonatomic, strong) UITabBarItem *item;
@end
