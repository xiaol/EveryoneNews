//
//  LPFloodView.h
//  EveryoneNews
//
//  Created by dongdan on 16/3/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPFloodView : UIView

@end
