//
//  TimeLineView.h
//  Test
//
//  Created by Feng on 15/7/7.
//  Copyright (c) 2015年 Feng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LPPressFrame;
@interface TimeLineView : UIView

@property (nonatomic, strong) LPPressFrame *pressFrame;

@end
