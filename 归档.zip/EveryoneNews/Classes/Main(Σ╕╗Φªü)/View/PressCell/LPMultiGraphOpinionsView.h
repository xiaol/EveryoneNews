//
//  LPMultiGraphOpinionsView.h
//  EveryoneNews
//
//  Created by apple on 15/6/3.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LPPressFrame;

@interface LPMultiGraphOpinionsView : UIView
@property (nonatomic, strong) NSArray *sublist;
@end
