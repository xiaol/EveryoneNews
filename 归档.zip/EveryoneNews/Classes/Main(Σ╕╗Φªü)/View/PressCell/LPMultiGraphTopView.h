//
//  LPMultiGraphTopView.h
//  EveryoneNews
//
//  Created by apple on 15/6/3.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LPPressFrame;

@interface LPMultiGraphTopView : UIView
@property (nonatomic, strong) LPPressFrame *pressFrame;
@end
