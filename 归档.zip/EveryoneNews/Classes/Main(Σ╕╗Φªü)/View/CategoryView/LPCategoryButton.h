//
//  LPCategoryButton.h
//  EveryoneNews
//
//  Created by apple on 15/6/1.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LPCategory;

@interface LPCategoryButton : UIButton
@property (nonatomic, strong) LPCategory *category;
@end
