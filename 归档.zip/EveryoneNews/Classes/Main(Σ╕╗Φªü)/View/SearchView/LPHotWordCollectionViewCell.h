//
//  LPHotWordCollectionViewCell.h
//  EveryoneNews
//
//  Created by dongdan on 16/1/9.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPHotWordCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) UILabel *hotWordLabel;
@property (nonatomic, copy) NSString *title;

@end
