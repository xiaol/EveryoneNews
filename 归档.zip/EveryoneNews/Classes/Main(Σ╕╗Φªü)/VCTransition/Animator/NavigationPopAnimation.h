//
//  NavigationPopAnimation.h
//  EveryoneNews
//
//  Created by apple on 15/10/4.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NavigationPopAnimation : NSObject <UIViewControllerAnimatedTransitioning>

@end
