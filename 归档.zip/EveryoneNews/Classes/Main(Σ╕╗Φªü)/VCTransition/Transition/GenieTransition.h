//
//  GenieTransition.h
//  EveryoneNews
//
//  Created by apple on 15/8/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GenieTransition : NSObject <UIViewControllerTransitioningDelegate>
//- (instancetype)initWithToViewController:(UIViewController *)toVc;
@end
