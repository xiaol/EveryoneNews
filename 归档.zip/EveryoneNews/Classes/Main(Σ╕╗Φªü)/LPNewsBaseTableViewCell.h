//
//  QDNewsBaseTableViewCell.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LPNewsBaseTableViewCell : UITableViewCell

- (void)setModel:(nonnull id)model IndexPath:(nullable NSIndexPath *)indexPath;

@end