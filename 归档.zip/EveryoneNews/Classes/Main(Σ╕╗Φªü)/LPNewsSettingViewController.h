//
//  LPNewsSettingViewController.h
//  EveryoneNews
//
//  Created by Yesdgq on 16/4/11.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPNewsBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LPNewsSettingViewController : LPNewsBaseViewController

@end
NS_ASSUME_NONNULL_END