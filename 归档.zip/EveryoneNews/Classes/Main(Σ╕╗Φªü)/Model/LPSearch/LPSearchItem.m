//
//  LPSearchItem.m
//  EveryoneNews
//
//  Created by dongdan on 16/1/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LPSearchItem.h"

@implementation LPSearchItem

@end
