//
//  LPSearchItem.h
//  EveryoneNews
//
//  Created by dongdan on 16/1/7.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LPSearchItem : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic ,copy) NSString *updateTime;
@property (nonatomic, copy) NSString *sourceSiteName;
@property (nonatomic, copy) NSString *sourceUrl;
@end
