//
//  LPConcern.h
//  EveryoneNews
//
//  Created by apple on 15/7/15.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LPConcern : NSObject
@property (nonatomic, copy) NSString *channel_name;
@property (nonatomic, copy) NSString *channel_ios_img;
@property (nonatomic, copy) NSString *channel_des;
@property (nonatomic, copy) NSString *channel_id;
@end
