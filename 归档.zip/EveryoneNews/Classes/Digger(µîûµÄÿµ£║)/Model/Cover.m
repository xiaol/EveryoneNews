//
//  Cover.m
//  EveryoneNews
//
//  Created by apple on 15/10/12.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "Cover.h"

@implementation Cover

@end
