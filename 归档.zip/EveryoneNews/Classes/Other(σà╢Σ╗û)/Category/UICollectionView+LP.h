//
//  UICollectionView+LP.h
//  EveryoneNews
//
//  Created by apple on 15/8/18.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICollectionView (LP)
- (void)reload;
@end
