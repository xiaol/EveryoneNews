//
//  UICollectionView+LP.m
//  EveryoneNews
//
//  Created by apple on 15/8/18.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "UICollectionView+LP.h"

@implementation UICollectionView (LP)
- (void)reload {
    
}
@end
