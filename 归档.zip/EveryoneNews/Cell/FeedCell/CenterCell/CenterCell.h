//
//  CenterCell.h
//  EveryoneNews
//
//  Created by 于咏畅 on 15/4/27.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Time;

@interface CenterCell : UITableViewCell

@property (nonatomic, assign)CGFloat cellH;

@property (nonatomic, strong)  Time *time;

@end
