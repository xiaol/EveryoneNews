//
//  Time.m
//  EveryoneNews
//
//  Created by apple on 15/5/22.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import "Time.h"

@implementation Time

@end
