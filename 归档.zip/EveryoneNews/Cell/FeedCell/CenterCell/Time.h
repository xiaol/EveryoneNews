//
//  Time.h
//  EveryoneNews
//
//  Created by apple on 15/5/22.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Time : NSObject

@property (nonatomic, copy) NSString *timeStr;

@property (nonatomic, strong) NSNumber *type;

@end
