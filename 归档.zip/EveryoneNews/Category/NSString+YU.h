//
//  NSString+YU.h
//  EveryoneNews
//
//  Created by 于咏畅 on 15/5/6.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (YU)
/**
 *  判断字符串是否为空
 *
 *  @param string 待判定字符串
 *
 *  @return bool
 */
+ (BOOL) isBlankString:(NSString *)string;

@end
