//
//  NSArray+isEmpty.h
//  EveryoneNews
//
//  Created by 于咏畅 on 15/5/18.
//  Copyright (c) 2015年 yyc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (isEmpty)

+(BOOL)isEmpty:(NSArray *)array;

@end
